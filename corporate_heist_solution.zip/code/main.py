
import re
import unicodedata
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier

SEED = 42
TOP_N = 500

def first_number(value):
    if pd.isna(value):
        return np.nan
    s = str(value).lower().replace(",", "")
    m = re.search(r"[-+]?\d+(?:\.\d+)?", s)
    return float(m.group(0)) if m else np.nan

def experience_years(value):
    if pd.isna(value):
        return np.nan
    s = str(value).lower()
    m = re.search(r"\d+(?:\.\d+)?", s)
    if not m:
        return np.nan
    v = float(m.group(0))
    if "month" in s or re.search(r"\bmo\b", s):
        return v / 12.0
    return v

def career_years(value):
    if pd.isna(value):
        return np.nan
    s = str(value).lower()
    total = 0.0
    found = False
    for m in re.finditer(
        r"(\d+(?:\.\d+)?)\s*(y|yr|yrs|year|years|mo|mos|month|months)",
        s,
    ):
        v = float(m.group(1))
        total += v if m.group(2).startswith("y") else v / 12.0
        found = True
    return total if found else np.nan

def contribution_count(value):
    if pd.isna(value):
        return np.nan
    s = str(value).lower().strip()
    if s in {"", "nan", "not tracked", "none"}:
        return np.nan
    vals = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", s)]
    return max(vals) if vals else np.nan

def norm_text(value):
    if pd.isna(value):
        return ""
    s = unicodedata.normalize("NFKD", str(value)).lower()
    return re.sub(r"[^a-z0-9]", "", s)

def build_features(df):
    x = df.copy()

    x["total_experience_num"] = x["total_experience"].map(experience_years)
    x["aptitude_score_num"] = x["aptitude_score"].map(first_number)
    x["last_rating_num"] = x["last_rating"].map(first_number)
    x["last_job_change_num"] = x["last_job_change"].map(first_number)
    x["current_ctc_num"] = x["current_ctc"].map(first_number)
    x["expected_ctc_num"] = x["expected_ctc"].map(first_number)
    x["notice_days"] = x["notice_period"].map(first_number)
    x["technical_assessment_num"] = x["technical_assessment"].map(first_number)

    x["kpi_bin"] = (
        x["kpi_met"].astype(str).str.lower()
        .map({"y":1, "yes":1, "true":1, "1":1, "n":0, "no":0, "false":0, "0":0})
    )
    x["enroll_bin"] = (
        x["currently_enrolled"].astype(str).str.lower()
        .map({"no_enrollment":0, "no":0, "false":0, "n":0,
              "full time course":1, "part time course":1,
              "yes":1, "y":1, "true":1})
    )
    x["overtime_bin"] = (
        x["overtime_history"].astype(str).str.lower()
        .map({"yes":1, "y":1, "true":1, "no":0, "n":0, "false":0})
    )

    x["skill_count"] = (
        x["skills"].fillna("").astype(str).str.count(r"[,;|]") +
        x["skills"].notna().astype(int)
    )
    x["career_len"] = (
        x["career_path"].fillna("").astype(str).str.count(r"->|>|→") +
        x["career_path"].notna().astype(int)
    )

    # Recruiter-note signals are deliberately simple and reproducible.
    note = x["recruiter_note"].fillna("").astype(str).str.lower()
    pos_words = ["excellent", "strong", "outstanding", "top", "great", "exceptional", "recommended"]
    neg_words = ["struggled", "weak", "poor", "lukewarm", "concern", "concerns", "flagged"]
    x["note_pos"] = sum(note.str.count(w) for w in pos_words)
    x["note_neg"] = sum(note.str.count(w) for w in neg_words)
    x["note_len"] = note.str.len()

    return x

BASE_COLS = [
    "age", "graduation_year", "institute", "degree", "major", "current_city",
    "applied_role", "current_title", "total_experience_num", "num_employers",
    "company_type", "company_size", "skills", "certifications",
    "technical_assessment_num", "aptitude_score_num", "last_rating_num",
    "kpi_bin", "awards", "trainings_last_year", "training_hours",
    "recruitment_channel", "last_job_change_num", "enroll_bin", "overtime_bin",
    "current_ctc_num", "expected_ctc_num", "notice_days", "recruiter_note",
    "skill_count", "career_len", "note_pos", "note_neg", "note_len"
]

CAT_COLS = [
    "institute", "degree", "major", "current_city", "applied_role",
    "current_title", "company_type", "company_size", "skills",
    "certifications", "awards", "recruitment_channel",
    "kpi_bin", "enroll_bin", "overtime_bin"
]

def prepare_model_frame(df):
    x = df[BASE_COLS].copy()
    for c in CAT_COLS:
        x[c] = x[c].fillna("__NA__").astype(str)
    for c in BASE_COLS:
        if c not in CAT_COLS:
            x[c] = pd.to_numeric(x[c], errors="coerce").fillna(-999)
    return x

def obvious_bad_profile(x):
    title = x["current_title"].fillna("").astype(str).str.lower()
    exp = x["total_experience_num"]
    career = x["career_path"].map(career_years)
    career_gap = (career - exp).abs()

    # The debrief explicitly says implausibly rapid title progression is rejected.
    overpromotion = (
        (title.str.contains(r"\b(vp|vice president|chief|director|head)\b", regex=True) & (exp < 8)) |
        (title.str.contains(r"\bmanager\b", regex=True) & (exp < 5)) |
        (title.str.contains(r"\blead\b", regex=True) & (exp < 3))
    )

    # Basic internal consistency checks for fabricated records.
    age_grad = 2026 - x["graduation_year"] + 20
    age_problem = x["age"].notna() & (x["age"] < age_grad - 1)
    exp_age_problem = (
        x["age"].notna() & exp.notna() &
        (exp > x["age"] - 18 + 2)
    )
    career_problem = career_gap.notna() & (career_gap > 8)

    # Joining after two months is explicitly ruled out this cycle.
    notice_problem = x["notice_days"] > 60

    return overpromotion | age_problem | exp_age_problem | career_problem | notice_problem

def identity_keys(df):
    out = pd.DataFrame(index=df.index)
    out["email"] = df["email"].map(norm_text)
    out["phone"] = df["phone"].map(norm_text)
    out["name"] = df["full_name"].map(norm_text)
    out["inst"] = df["institute"].map(norm_text)
    out["grad"] = df["graduation_year"].astype(str)
    out["role"] = df["applied_role"].map(norm_text)
    return out

def select_unique(df, score):
    keys = identity_keys(df)
    seen = set()
    selected = []
    order = np.argsort(-score, kind="mergesort")

    for i in order:
        # Strong duplicate evidence: same normalized email/phone.
        strong = []
        if keys.iloc[i]["email"]:
            strong.append(("e", keys.iloc[i]["email"]))
        if keys.iloc[i]["phone"]:
            strong.append(("p", keys.iloc[i]["phone"]))

        # Secondary duplicate evidence: exact same name + institute + graduation + role.
        secondary = None
        if all(keys.iloc[i][c] for c in ["name", "inst", "grad", "role"]):
            secondary = ("s", keys.iloc[i]["name"], keys.iloc[i]["inst"],
                         keys.iloc[i]["grad"], keys.iloc[i]["role"])

        if any(k in seen for k in strong) or (secondary is not None and secondary in seen):
            continue

        selected.append(i)
        seen.update(strong)
        if secondary is not None:
            seen.add(secondary)

        if len(selected) == TOP_N:
            break

    if len(selected) < TOP_N:
        raise RuntimeError("Could not select 500 unique candidates.")
    return selected

def main():
    train = pd.read_csv("train.csv")
    test = pd.read_csv("test.csv")

    train_f = build_features(train)
    test_f = build_features(test)

    y = (train["post_hire_score"] >= train["post_hire_score"].quantile(0.95)).astype(int)

    X_train = prepare_model_frame(train_f)
    X_test = prepare_model_frame(test_f)

    model = CatBoostClassifier(
        iterations=700,
        depth=7,
        learning_rate=0.05,
        loss_function="Logloss",
        eval_metric="AUC",
        random_seed=SEED,
        verbose=False,
        thread_count=2,
        allow_writing_files=False,
    )
    model.fit(X_train, y, cat_features=CAT_COLS)

    base_score = model.predict_proba(X_test)[:, 1]
    score = base_score.astype(float).copy()

    # Current-cycle rule: sustained public code contribution is a new fast-track signal.
    c = test_f["public_code_contributions"].map(contribution_count).fillna(0).to_numpy()
    score += np.select(
        [c >= 100, c >= 50, c >= 30, c >= 20, c >= 10, c >= 5],
        [0.14, 0.12, 0.10, 0.075, 0.035, 0.01],
        default=0.0,
    )

    # New colleges are specifically described as successful this cycle when technical fit is high.
    train_institutes = {norm_text(v) for v in train["institute"].dropna()}
    new_college = ~test["institute"].map(norm_text).isin(train_institutes)
    tech = test_f["technical_assessment_num"].fillna(-999)
    score += np.where(new_college & (tech >= 90), 0.05,
                      np.where(new_college & (tech >= 80), 0.03, 0.0))

    # Hard exclusions from the insider's explicit rules and consistency checks.
    bad = obvious_bad_profile(test_f).to_numpy()
    score[bad] = -1e9

    # Never return the same real person twice. During sorting, keep the higher-scoring entry.
    selected = select_unique(test_f, score)

    result = pd.DataFrame({
        "rank": np.arange(1, TOP_N + 1),
        "candidate_id": test.loc[selected, "candidate_id"].values,
    })
    result.to_csv("submission.csv", index=False)
    print("Wrote submission.csv with", len(result), "rows.")

if __name__ == "__main__":
    main()
